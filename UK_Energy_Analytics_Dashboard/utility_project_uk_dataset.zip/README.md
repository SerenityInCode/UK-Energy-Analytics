
Utility Analytics Synthetic Dataset (UK) - README
===============================================

Files included:
- dim_region.csv     : Region lookup table (RegionID, RegionName)
- dim_tariff.csv     : Tariff table (TariffID, CustomerType, Price_per_kWh)
- dim_customer.csv   : Customers (~1000) with CustomerID, CustomerName, RegionID, CustomerType
- dim_date.csv       : Hourly DateTime dimension for 2024-01-01 to 2024-03-31
- fact_energy_readings.csv : Fact table (~50000 rows) with hourly sampled readings

Suggested Power BI import steps:
1. Open Power BI Desktop (Windows).
2. Get Data -> Text/CSV, and import all CSV files from this folder.
3. In Power Query Editor, ensure data types:
   - dim_date.DateTime -> Date/Time
   - dim_date.Date -> Date
   - fact_energy_readings.DateTime -> Date/Time
   - CustomerID, RegionID -> Whole Number
4. Build relationships (Model view):
   - fact_energy_readings.CustomerID -> dim_customer.CustomerID
   - fact_energy_readings.RegionID -> dim_region.RegionID
   - fact_energy_readings.DateTime -> dim_date.DateTime
5. Mark dim_date as a Date table (if using daily aggregation, you can create a Date-only column).

Notes:
- Revenue is NOT precomputed. Use dim_tariff and dim_customer.CustomerType to calculate revenue in Power BI via DAX.
- The dataset is synthetic and designed for learning & demonstration.

