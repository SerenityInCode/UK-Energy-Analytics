
Power BI Build Plan (MVP - Finish in one day)
=============================================

1) Data model (star schema)
   - Fact: fact_energy_readings
   - Dimensions: dim_date, dim_customer, dim_region, dim_tariff

2) Recommended relationships:
   - fact_energy_readings.CustomerID -> dim_customer.CustomerID (many-to-one)
   - fact_energy_readings.RegionID -> dim_region.RegionID (many-to-one)
   - fact_energy_readings.DateTime -> dim_date.DateTime (many-to-one)

3) Important DAX measures to create:
   - Total Consumption (kWh) = SUM(fact_energy_readings[Consumption_kWh])
   - Total Revenue (£) = SUMX(fact_energy_readings, fact_energy_readings[Consumption_kWh] * RELATED(dim_tariff[Price_per_kWh]))
   - Avg Temperature = AVERAGE(fact_energy_readings[Temperature_C])
   - YoY Consumption Growth (%) = DIVIDE([Total Consumption] - CALCULATE([Total Consumption], SAMEPERIODLASTYEAR(dim_date[Date])), CALCULATE([Total Consumption], SAMEPERIODLASTYEAR(dim_date[Date])))
     (Note: SAMEPERIODLASTYEAR works on a proper Date table with daily granularity)

4) Visuals to build (MVP):
   - Executive page:
     * Card: Total Consumption (kWh)
     * Card: Total Revenue (£)
     * Line chart: Consumption over time (add Forecast in Analytics pane)
     * Bar: Revenue by Region
   - Operational page:
     * Hourly line chart for selected day/week
     * Scatter: Temperature vs Consumption
     * Table: Top 10 customers by consumption
   - Add Slicers: Region, CustomerType, Month

5) Row-Level Security (RLS) (simple demo):
   - Create roles in Modeling -> Manage Roles. Example role filter:
     dim_region[RegionName] = "London"
   - Test with View As roles.

6) Polishing:
   - Format numbers (kWh with 1 decimal, £ with 2 decimals)
   - Add titles and short descriptions on each page
   - Add a short README slide and a 2-3 minute walkthrough recording for recruiters.

Good luck — you can complete the MVP following the plan above in about 6-8 hours.
